# Get Programming with F#

This repository contains all F# code listings as required for all exercises and samples within the 'Get Programming with F#' book, available [here]( https://www.manning.com/books/get-programming-with-f-sharp).

To install all dependencies as needed for the exercises, simply run the build.cmd file, which uses Paket to download all NuGet dependencies.
