﻿[<EntryPoint>]
let main argv =
    let tony = CSharpProject.Person "Tony"
    tony.PrintName()
    0
