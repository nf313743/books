﻿namespace Domain

type Customer =
    { FirstName : string
      LastName : string
      Age : int }
