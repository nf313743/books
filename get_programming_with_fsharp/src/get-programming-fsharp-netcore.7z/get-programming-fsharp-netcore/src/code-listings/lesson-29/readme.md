## Sorry!
This lesson uses WPF, which is currently .NET Framework only. NET Core v3 will allow WPF, but only on Windows machines.