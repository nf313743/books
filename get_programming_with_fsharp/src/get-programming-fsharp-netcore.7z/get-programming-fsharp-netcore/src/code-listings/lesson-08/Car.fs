﻿module Car

open System

//TODO: Create helper functions to provide the building blocks to implement driveTo.

/// Drives to a given destination given a starting amount of petrol
let driveTo (petrol, destination) = petrol